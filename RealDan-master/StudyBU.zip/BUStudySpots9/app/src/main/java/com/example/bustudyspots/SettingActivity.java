package com.example.bustudyspots;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class SettingActivity extends AppCompatActivity {

    private Button save_changes_button;
    public CheckBox cafe;
    public CheckBox libraries;
    public CheckBox BUonly;
    public CheckBox allPlaces;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setting_activity);

        save_changes_button = (Button)findViewById(R.id.savechangesbutton);
        save_changes_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMapActivity();
            }
        });

        cafe = (CheckBox)findViewById(R.id.cafeCheckBox);
        libraries = (CheckBox)findViewById(R.id.libraryCheckBox);
        BUonly = (CheckBox)findViewById(R.id.BUonlyCheckBox);
        allPlaces = (CheckBox)findViewById(R.id.allPlacesCheckBox);


        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void openMapActivity()
    {
        Intent openMap = new Intent(this, MapActivity.class);
        startActivity(openMap);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == android.R.id.home)
        {
            this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean cafeisChecked ()
    {
        if (cafe.isChecked())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean libraryisChecked ()
    {
        if (libraries.isChecked())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean BUonlyisChecked ()
    {
        if (BUonly.isChecked())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public boolean allPlacesChecked ()
    {
        if (allPlaces.isChecked())
        {
            return true;
        }
        else
        {
            return false;
        }
    }

}
